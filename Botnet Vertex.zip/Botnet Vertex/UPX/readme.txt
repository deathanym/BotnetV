		  __     __        _            _   _ _____ _____
		  \ \   / /__ _ __| |_ _____  _| \ | | ____|_   _|
		   \ \ / / _ \ '__| __/ _ \ \/ /  \| |  _|   | |
		    \ V /  __/ |  | ||  __/>  <| |\  | |___  | |
		     \_/ \___|_|   \__\___/_/\_\_| \_|_____| |_|
		       [From DarkCoderSc Freewares since 2k6]  
		       
UPX (Ultimate Packer for eXecutables)
This tool will compress the loader and make it smaller and will still be fully
functionnal.

Downloaded from upx.sourceforge.com

Hashs:

MD5:308f709a8f01371a6dd088a793e65a5f
SHA:a07c073d807ab0119b090821ee29edaae481e530
CRC:1266d6ec
