<?php
	/**
		About page
		by DarkCoderSc
	
	*/
	
	include('inc/sessioncontrol.inc.php'); // test if user is logged
	
?>

<h1 class="aboutico">Panel settings</h1>

<div style="padding:5px;">
	<img style="float:right; margin-right:5px; margin-top:20px;" src="imgs/vabout.png"></img>
		<div id="coolbox">
				<u><b>About the author:</b></u><br/><br/>
				<table>
					<tr>
						<td>Panel coded by : </td><td><b>DarkCoderSc</b></td>
					</tr>
					<tr>
						<td>Using languages : </td><td><b>CSS3,HTML,JAVASCRIPT,PHP</b></td>
					</tr>
					<tr><td colspan=2><center><img src="imgs/separator.png"></img></center></td></tr>
					<tr>
						<td>Loader (bin) coded by : </td><td><b>DarkCoderSc</b></td>
					</tr>
					<tr>
						<td>Using language : </td><td><b>C++ (Visual Studio 2008)</b></td>
					</tr>
					<tr><td colspan=2><center><img src="imgs/separator.png"></img></center></td></tr>
					<tr>
						<td>Builder (bin) coded by : </td><td><b>DarkCoderSc</b></td>
					</tr>
					<tr>
						<td>Using language : </td><td><b>CodeGear Delphi XE</b></td>
					</tr>
					<tr><td colspan=2><center><img src="imgs/separator.png"></img></center></td></tr>
					<tr>
						<td>Panel design by : </td><td><b>DarkCoderSc</b></td>
					</tr>
					<tr>
						<td>Using : </td><td><b>My imagination :D</b></td>
					</tr>
					<tr><td colspan=2><center><img src="imgs/separator.png"></img></center></td></tr>
					<tr>
						<td>Panel main PNG logo  : </td><td><b>Ayoub Iskandar Visiongfx</b></td>
					</tr>
					<tr>
						<td>Using : </td><td><b>his graphics skill'z</b></td>
					</tr>
				</table>
				
				<br/><br/>
				This pieace of software was made in France, o yeah "Vive la france mes amis et amies ;] on va boire du champagne !!!!!".<br/>
		</div>
		<br/><br/>
		
		<div id="coolbox" align="center"> 
			<u><b>Yeah dudes i'm social :</b></u><br/><br/>
				<a href="http://www.facebook.com/pages/DarkCoderSc/126834104041907"><img src="imgs/facebook.png"></img></a>
					&nbsp;
				<a href="http://twitter.com/DarkCoderSc"><img src="imgs/twitter.png"></img></a>
					&nbsp;
				<a href="http://youtube.com/DarkCoderSc"><img src="imgs/youtube.png"></img></a>
					&nbsp;
				<a href="http://fr.linkedin.com/pub/jean-pierre-lesueur/24/745/a8a"><img src="imgs/lin.png"></img></a>
					&nbsp;
				<a href="http://unremote.org/?feed=rss2"><img src="imgs/rss.png"></img></a>
					&nbsp;
				<a href="http://eaxcoders.com/"><img src="imgs/site.png"></img></a>
		</div>
		
		<br/><br/>
		
		<div id="coolbox">
			<u><b>Cool websites:</b></u><br/><br/>
			<a href="http://vertexnet-loader.com/">http://vertexnet-loader.com/ (Official vertexnet loader website)</a><br/>
			<a href="http://unremote.org/">http://unremote.org/ (my main product website)</a><br/>
			<a href="http://darkcomet-rat.com/">http://darkcomet-rat.com/ (my official RAT website)</a><br/>
			<a href="http://www.opensc.ws/">http://www.opensc.ws/ (awesome security forum)</a><br/>
			<a href="http://www.hackhound.org/">http://www.hackhound.org/ (awesome security forum)</a><br/>
			<a href="http://www.eaxcoders.com/">http://www.eaxcoders.com/ (My french security forum)</a>
		</div>
		
		<br/><br/>
	
		<div id="coolbox">
			<u><b>VertexNet story:</b></u><br/><br/>
			<p>
				So i decide to code VertexNet at the middle of Janurary 2011 months , and it tooks about 1 month to release the first version to public, it took
				me hours and hours of work to make this product and like every time 100% free.<br/>
				Why all my products are free ? , simply because i already have a good work in a french IT and i like to code in my free time for free, my goal is
				to make the best security products (better than private ones) but for free then everybody can profit of my knowledge and then tools i create.<br/>
				I Decide to name it VertexNet cause like the name of Vertex (in mathematics) and Net like Network (no not like .NET don't worry lol).<br/><br/>
				Nice history about the creation of this tool is that i never open a botnet/loader source before to know how they was working my chalenge was remake
				the botnet/loader principe by my own like if i was the first to do that, so i make it only via guess about how Zeus was working , for me he was using a 
				GET keep alive and to post strong data he was using sample POST then i decide to make via my own method the same stuff (maybe my way to do it is wrong
				or better i don't know you willl tell me).<br/><br/>
				Last thing please guy's don't use this software for bad reason be fair with me profit of my free tools but for your personnal uses only.<br/>
				And this tool can be use under a company without any restrictions.
			</p>
		</div>
		
</div>
<br/>