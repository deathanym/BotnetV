<?php
	/**
		Related file for Database configuration
		***************************************
		By DarkCoderSc.
	*/

	//{Global variables accessible even by functions}
	$GLOBALS["dbhost"] = "fdb14.biz.nf"; // DATABASE HOST DNS/IP
	$GLOBALS["dbname"] = "2260875_deathbot"; // DATABASE NAME
	$GLOBALS["dbuser"] = "2260875_deathbot";      // DATABASE USERNAME
	$GLOBALS["dbpass"] = "Qweasd123";          // DATABASE PASSWORD
	
	/**
		Start a new connection to database
	*/
	function getDBSock(){
		$sock = mysql_connect($GLOBALS["dbhost"],$GLOBALS["dbuser"],$GLOBALS["dbpass"]); 
		if ( ! $sock ) die ("Connection error"); 
		mysql_select_db($GLOBALS["dbname"], $sock) or die ("Connection error");
		return $sock; // Return our socket handle 
	}
	
?>
